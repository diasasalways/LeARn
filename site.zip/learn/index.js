
const firebaseConfig = {
    apiKey: "AIzaSyDKox_7kTy45LM46D_rpBD_7IbO1JSCSLg",
    authDomain: "learn-650e0.firebaseapp.com",
    projectId: "learn-650e0",
    storageBucket: "learn-650e0.appspot.com",
    messagingSenderId: "831080304174",
    appId: "1:831080304174:web:0623e7e4255234fa11d9bf"
  };
firebase.initializeApp(firebaseConfig);

var fileText = document.querySelector(".fileText");
var fileItem;
var fileName;


/*var imgText = document.querySelector(".imgText");
var imgItem;
var imgName;*/


function getFile(e){
    fileItem = e.target.files[0];
    fileName = fileItem.name;
    fileText.innerHTML = fileName;

}
/*function getImg(e){
    imgItem = e.target.files[0];
    imgName = imgItem.name;
    imgText.innerHTML = imgName;

}*/

function upload(){
    let storageRef = firebase.storage().ref(fileName);
    let uploadTask = storageRef.put(fileItem);

    uploadTask.on("state_changed", (snapshot) =>{
        console.log(snapshot);
    },(error)=>{
        console.log("ERROR",error);
    },()=>{
        uploadTask.snapshot.ref.getDownloadURL().then((url)=>{
            console.log("URL",url);
        })
    })
}